//
//  XMPPConfig.h
//  XMPPSample
//
//  Created by songjc on 16/12/1.
//  Copyright © 2016年 Don9. All rights reserved.
//

#ifndef XMPPSample_XMPPConfig_h
#define XMPPSample_XMPPConfig_h

// openfire服务器IP地址
#define  kHostName      @"192.168.3.18"

//#define  kHostName      @"192.168.0.100"

// openfire服务器端口 默认5222
#define  kHostPort      5222
// openfire服务器名称
#define kDomin @"127.0.0.1"
// resource(资源)
#define kResource @"ios"

#endif
