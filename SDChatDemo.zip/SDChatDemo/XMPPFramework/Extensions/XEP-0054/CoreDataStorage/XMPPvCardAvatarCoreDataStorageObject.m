//
//  XMPPvCardAvatarCoreDataStorageObject.m
//  XEP-0054 vCard-temp
//
//  Originally created by Eric Chamberlain on 3/18/11.
//

#import "XMPPvCardAvatarCoreDataStorageObject.h"
#import "XMPPvCardCoreDataStorageObject.h"


@implementation XMPPvCardAvatarCoreDataStorageObject

@dynamic photoData;
@dynamic vCard;

@end
