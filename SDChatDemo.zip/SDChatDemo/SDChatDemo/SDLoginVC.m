//
//  SDLoginVC.m
//  SDChatDemo
//
//  Created by songjc on 16/12/2.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "SDLoginVC.h"
#import "SDRegisterVC.h"
#import "XMPPFramework.h"
#import "SDUser.h"
#import "SDContactsVC.h"
@interface SDLoginVC ()<UITextFieldDelegate,XMPPStreamDelegate>

@property(nonatomic,strong)UIButton *loginButton;

@property(nonatomic,strong)UIButton *registerButton;

@property(nonatomic,strong)UITextField *userName;

@property(nonatomic,strong)UITextField *passWord;

@property(nonatomic,strong)UIImageView *logoImageView;

@property(nonatomic,strong)UINavigationController *contactNC;//跳转的主控制器

@end

@implementation SDLoginVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    SDXmppManager *manager = [SDXmppManager defaulManager];
    [manager.stream addDelegate:self delegateQueue:dispatch_get_main_queue()];
    [self.frontRollView addSubview:self.logoImageView];
    [self.frontRollView addSubview:self.userName];
    [self.frontRollView addSubview:self.passWord];
    [self.frontRollView addSubview:self.loginButton];
    [self.frontRollView addSubview:self.registerButton];

}



-(UIImageView *)logoImageView{

    if (nil == _logoImageView) {
        
        _logoImageView = [[UIImageView alloc] initWithFrame:CGRectMake(KmainWidth/2-50, 100, 90, 80)];
        
        _logoImageView.image = [UIImage imageNamed:@"SDChatLogo.png"];
        
        
    }
    

    return _logoImageView;
}

-(UITextField *)userName{

    if (nil == _userName) {
        
        _userName = [[UITextField alloc]initWithFrame:CGRectMake(KmainWidth/2-150, 200, 300, 40)];
        
        _userName.backgroundColor = [UIColor whiteColor];
        
        UIView *leftView = [[UIView alloc]initWithFrame:CGRectMake(0,0,40,40)];
        
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 30 ,30)];
        
        imageView.image = [UIImage imageNamed:@"用户.png"];
        
        [leftView addSubview:imageView];
        
        imageView.center = leftView.center;
        
        [_userName setLeftView:leftView];
        
        [_userName setLeftViewMode:UITextFieldViewModeAlways];
        
        _userName.placeholder = @"请输入账号";
        
        _userName.delegate = self;
        
        _userName.layer.cornerRadius = 4;
        
        _userName.layer.masksToBounds = YES;
    }

    return _userName;

}

-(UITextField *)passWord{

    if (nil == _passWord) {
        _passWord = [[UITextField alloc]initWithFrame:CGRectMake(KmainWidth/2-150, 260, 300, 40)];
        
        _passWord.backgroundColor = [UIColor whiteColor];
                
        UIView *leftView = [[UIView alloc]initWithFrame:CGRectMake(0,0,40,40)];
        
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 30 ,30)];        imageView.image = [UIImage imageNamed:@"密码.png"];

        [leftView addSubview:imageView];
        
        imageView.center = leftView.center;
        
        [_passWord setLeftView:leftView];

        [_passWord setLeftViewMode:UITextFieldViewModeAlways];
        
        _passWord.placeholder = @"请输入密码";
        
        _passWord.delegate = self;
        
        _passWord.layer.cornerRadius = 4;
        
        _passWord.layer.masksToBounds = YES;
        
        _passWord.secureTextEntry = YES;
    }
    return _passWord;

}

-(UIButton *)loginButton{
    
    if (nil == _loginButton) {
        
        _loginButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _loginButton.frame = CGRectMake(KmainWidth/2 +30, 340, 120,40 );
        [_loginButton setTitle:@"登录" forState:UIControlStateNormal];
        [_loginButton setTintColor:[UIColor whiteColor]];
        _loginButton.backgroundColor = [UIColor orangeColor];
        _loginButton.layer.cornerRadius = 4;
        _loginButton.layer.masksToBounds = YES;
        [_loginButton addTarget:self action:@selector(skipAppRootMainViewController) forControlEvents:UIControlEventTouchUpInside];
        
    }
    
    return _loginButton;
    
}


-(UIButton *)registerButton{

    if (nil == _registerButton) {
        
        _registerButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _registerButton.frame = CGRectMake(KmainWidth/2 -150 , 340, 120,40 );
        [_registerButton setTitle:@"注册" forState:UIControlStateNormal];
        [_registerButton setTintColor:[UIColor whiteColor]];
        _registerButton.backgroundColor = [UIColor orangeColor];
        _registerButton.layer.cornerRadius = 4;
        _registerButton.layer.masksToBounds = YES;
        [_registerButton addTarget:self action:@selector(pushRegisterVC) forControlEvents:UIControlEventTouchUpInside];

    }
    
    return _registerButton;



}

//登录操作
-(void)skipAppRootMainViewController{

    SDXmppManager *manager = [SDXmppManager defaulManager];

    [manager loginWithUserName:self.userName.text AndPassWord:self.passWord.text];
    
    [_passWord resignFirstResponder];
    [_userName resignFirstResponder];
    
    [self loadSDContactVC];
    
}

-(void)loadSDContactVC{

    self.contactNC = [[UINavigationController alloc]initWithRootViewController:[[SDContactsVC alloc]init]];
    
}

-(void)pushRegisterVC{
    UINavigationController *registerNC = [[UINavigationController alloc]initWithRootViewController:[[SDRegisterVC alloc]init]];

    [self presentViewController:registerNC animated:YES completion:nil];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    [_passWord resignFirstResponder];
    [_userName resignFirstResponder];


}

//登录成功!跳转页面(代理实现)
- (void)xmppStreamDidAuthenticate:(XMPPStream *)sender{

    
    XMPPPresence *presence =  [XMPPPresence presenceWithType:@"available"];
    
    [[SDXmppManager defaulManager].stream sendElement:presence];
    
    [SDUser defaulUser].jid =[XMPPJID jidWithUser:self.userName.text domain:kDomin resource:kResource];
    [SDUser defaulUser].password = self.passWord.text;
    [[SDXmppManager defaulManager].roster fetchRoster];

    
    if (self.timer !=nil) {
        
        [self.timer invalidate];
        self.timer = nil;
    }
    
    if (self.rollTimer != nil) {
        [self.rollTimer invalidate];
        self.rollTimer = nil;
    }
    
    self.view.window.rootViewController = self.contactNC;

}

//认证失败的时候调用的.
-(void)xmppStream:(XMPPStream *)sender didNotAuthenticate:(DDXMLElement *)error{
    
    UIAlertController *alertView = [UIAlertController alertControllerWithTitle:@"登录失败" message:@"请检查账号密码" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleCancel handler:nil];
    
    [alertView addAction:action];
    
    [self presentViewController:alertView animated:YES completion:nil];
    
}


-(void)dealloc{
    
    
    if (self.timer !=nil) {
        
        [self.timer invalidate];
        self.timer = nil;
    }
    
    if (self.rollTimer != nil) {
        [self.rollTimer invalidate];
        self.rollTimer = nil;
    }
    
    
}

@end
