//
//  SDUser.h
//  SDChatDemo
//
//  Created by songjc on 16/12/5.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@class XMPPJID;
@class XMPPvCardTemp;
@interface SDUser : NSObject
//SDUser是当前用户信息的一个单例类.包含着用户信息以及好友请求数组


+(instancetype)defaulUser;



//用户密码
@property(nonatomic,strong)NSString *password;



//用户的JID
@property(nonatomic,copy) XMPPJID *jid;
//用户头像
@property(nonatomic,strong)UIImage *headerImage;
//用户名片
@property(nonatomic,strong)XMPPvCardTemp *vCard;



//从服务器获取到的好友数组.(杂乱无章,需要排序)
@property(nonatomic,strong)NSMutableArray *contactsArray;
//请求好友数组.存储的是请求者的JID
@property(nonatomic,strong)NSMutableArray  <XMPPJID*>*addFriendArray;

//用户当前界面是在登录界面还是注册界面主要是因为代理方法的调用问题而设置的BOOL值.
@property(nonatomic,assign)BOOL isLogin;

//清除所有数据
+(void)clearAllData;

@end
