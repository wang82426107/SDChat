//
//  SDChatVC.h
//  SDChatDemo
//
//  Created by songjc on 16/11/30.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SDXmppManager.h"
#import "SDContactModel.h"

@interface SDChatVC : UIViewController

//SDChatVC是聊天页面
@property(nonatomic,strong)SDContactModel *chatToPeople;//聊天人的信息

@end
