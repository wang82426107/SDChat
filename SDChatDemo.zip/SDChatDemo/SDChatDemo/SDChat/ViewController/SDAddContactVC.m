//
//  SDAddContactVC.m
//  SDChatDemo
//
//  Created by songjc on 16/12/2.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "SDAddContactVC.h"
#import "XMPPFramework.h"
#import "SDXmppManager.h"
#import "SDAddContactCell.h"
#import "SDUser.h"
@interface SDAddContactVC ()<UIAlertViewDelegate,XMPPRosterDelegate,UITableViewDelegate,UITableViewDataSource,SDAddContactCellDelegate,XMPPStreamDelegate>

@property(nonatomic,strong)UITableView *addFirendList;//请求好友列表.



@end


@implementation SDAddContactVC

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor colorWithPatternImage:[self reSizeImage:[UIImage imageNamed:@"SDBundle.bundle/没有好友请求.png"] toSize:CGSizeMake(KmainWidth, KmainHight)]];
    
    SDXmppManager *manager = [SDXmppManager defaulManager];
    [manager.roster addDelegate:self delegateQueue:dispatch_get_main_queue()];
    [manager.stream addDelegate:self delegateQueue:dispatch_get_main_queue()];

    [self loadNavigationView];
    [self loadAddFirendList];
    
    //添加新的好友的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addNewContactAction) name:AddNewContectMessage object:nil];
    

}





-(void)loadNavigationView{
    
    self.navigationItem.title = @"新的朋友";
    self.navigationController.navigationBar.barTintColor = SDcolor(21, 21, 21);
    [self.navigationController.navigationBar setTitleTextAttributes:
     
     @{NSFontAttributeName: [UIFont fontWithName:@"Helvetica-Bold" size:18],
       
       NSForegroundColorAttributeName:[UIColor whiteColor]}];
    
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(popVC)];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"添加好友" style:UIBarButtonItemStylePlain target:self action:@selector(addNewContact)];
    
    
    [self.navigationItem.leftBarButtonItem setTitleTextAttributes:@{NSFontAttributeName: [UIFont fontWithName:@"Helvetica-Bold" size:17],
                                                                    
                                                                    NSForegroundColorAttributeName:[UIColor whiteColor]} forState:UIControlStateNormal];
    
    
    [self.navigationItem.rightBarButtonItem setTitleTextAttributes:@{NSFontAttributeName: [UIFont fontWithName:@"Helvetica-Bold" size:17],
                                                                     
                                                                     NSForegroundColorAttributeName:[UIColor whiteColor]} forState:UIControlStateNormal];
    
    
}


-(void)popVC{

    [self.navigationController popViewControllerAnimated:YES];

}

#pragma mark ----请求消息列表----
//初始化
-(void)loadAddFirendList{

    self.addFirendList = [[UITableView alloc]initWithFrame:CGRectMake(0, 64, KmainWidth, KmainHight-64) style:UITableViewStylePlain];
    
    self.addFirendList.backgroundColor = SDcolor(240, 240, 240);
    
    self.addFirendList.delegate = self;
    
    self.addFirendList.dataSource = self;
    
    self.addFirendList.separatorStyle = NO;
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    [self.addFirendList registerClass:[SDAddContactCell class] forCellReuseIdentifier:@"SDAddContactCell"];
    
    [self.view addSubview:self.addFirendList];
    
    [self hiddenAddFirendList];

}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return [SDUser defaulUser].addFriendArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    SDAddContactCell *cell  =[tableView dequeueReusableCellWithIdentifier:@"SDAddContactCell"];
    
    cell.agreeButton.layer.borderColor = (__bridge CGColorRef _Nullable)([UIColor greenColor]);
    cell.agreeButton.layer.borderWidth = 1;
    cell.disagreeButton.layer.borderColor = (__bridge CGColorRef _Nullable)([UIColor redColor]);
    cell.disagreeButton.layer.borderWidth = 1;
    cell.delegate = self;
    XMPPJID *requestJID =  [SDUser defaulUser].addFriendArray[indexPath.row];
    cell.friendidLabel.text = requestJID.user;
    cell.selectionStyle = UITableViewCellSeparatorStyleNone;
    
    return cell;


}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return 60;

}



-(void)agreeWithFriendRequest:(NSString *)jidUser{
    
    XMPPJID *jidName = [XMPPJID jidWithUser:jidUser domain:kDomin resource:kResource];
    XMPPRoster *roster = [SDXmppManager defaulManager].roster;

    [roster acceptPresenceSubscriptionRequestFrom:jidName andAddToRoster:YES];
    
    XMPPJID *deleteJID;
    for (int i = 0; i<[SDUser defaulUser].addFriendArray.count; i++) {
        
        XMPPJID *obj = [SDUser defaulUser].addFriendArray[i];
        
        if ([obj.user isEqualToString:jidUser]) {
            
            deleteJID = obj;
        }
        
    }
    
    [[SDUser defaulUser].addFriendArray removeObject:deleteJID];
    
    [self.addFirendList reloadData];

        UIAlertController *alerView =[UIAlertController alertControllerWithTitle:@"添加成功!" message:[NSString stringWithFormat:@"成功添加:%@成为了好友",jidName.user] preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *alertAction = [UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleCancel handler:nil];
    
    [alerView addAction: alertAction];
    
    [self presentViewController:alerView animated:YES completion:nil];

    [self.addFirendList reloadData];
    
    [self hiddenAddFirendList];


}

-(void)disagressWithFriendRequest:(NSString *)jidUser{
    
    XMPPJID *jidName = [XMPPJID jidWithUser:jidUser domain:kDomin resource:kResource];
    XMPPRoster *roster = [SDXmppManager defaulManager].roster;
    
    [roster rejectPresenceSubscriptionRequestFrom:jidName];
    
    XMPPJID *deleteJID;
    for (int i = 0; i<[SDUser defaulUser].addFriendArray.count; i++) {
        
        XMPPJID *obj = [SDUser defaulUser].addFriendArray[i];
        
        if ([obj.user isEqualToString:jidUser]) {
            
            deleteJID = obj;
        }
        
    }
    
    [[SDXmppManager defaulManager].roster removeUser:jidName];

    [[SDUser defaulUser].addFriendArray removeObject:deleteJID];
    [self.addFirendList reloadData];
    UIAlertController *alerView =[UIAlertController alertControllerWithTitle:@"操作成功!" message:[NSString stringWithFormat:@"你已拒绝了:%@的好友请求",jidName.user] preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *alertAction = [UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleCancel handler:nil];
    
    [alerView addAction: alertAction];
    
    [self presentViewController:alerView animated:YES completion:nil];
    
    [self.addFirendList reloadData];
    [self hiddenAddFirendList];

}



#pragma mark ----添加好友相关----

//添加新的联系人的通知
-(void)addNewContactAction{
    
 
    [self.addFirendList reloadData];
    
    [self hiddenAddFirendList];
    
}



-(void)addNewContact{

    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"好友账号" message:@"" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定",nil];
    
    [alert setAlertViewStyle:UIAlertViewStylePlainTextInput];
    [alert show];
    
    
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    if (buttonIndex == 1) {
        UITextField *textField = [alertView textFieldAtIndex:0];
        
        [self XMPPAddFriendSubscribe:textField.text];

    }

}

//添加好友
- (void)XMPPAddFriendSubscribe:(NSString *)name
{
    //XMPPHOST 就是服务器名，  主机名
    XMPPJID *jid = [XMPPJID jidWithUser:name domain:kDomin resource:kResource];
    [[SDXmppManager defaulManager].roster subscribePresenceToUser:jid];

    
}




//修改图片尺寸
- (UIImage *)reSizeImage:(UIImage *)image toSize:(CGSize)reSize{
    
    UIGraphicsBeginImageContext(CGSizeMake(reSize.width, reSize.height));
    
    [image drawInRect:CGRectMake(0, 0, reSize.width, reSize.height)];
    
    UIImage *reSizeImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return reSizeImage;
    
}



//根据单例中请求好友数据的个数量判断是否显示豪情请求列表
-(void)hiddenAddFirendList{
    
    if ([SDUser defaulUser].addFriendArray.count ==0) {
        
        self.addFirendList.hidden = YES;
        
    }else{
        
        self.addFirendList.hidden = NO;
        
    }
    
}



-(void)dealloc{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];

}


@end
