//
//  SDContactsVC.m
//  SDChatDemo
//
//  Created by songjc on 16/11/30.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "SDContactsVC.h"
#import "ContactCell.h"
#import "FunctionCell.h"
#import "SDChatVC.h"
#import "SDAddContactVC.h"
#import "SDXmppManager.h"
#import "XMPPFramework.h"
#import "UserInformationView.h"
#import "SDLoginVC.h"
#import "SDUser.h"
#import "SDContactModel.h"
#import <UIKit/UIImagePickerController.h>

@interface SDContactsVC ()<UITableViewDelegate,UITableViewDataSource,XMPPRosterDelegate,UserInformationViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,XMPPvCardAvatarDelegate,XMPPvCardTempModuleDelegate>

@property(nonatomic,strong)UITableView *contactsList;//好友列表

@property(nonatomic,strong)NSMutableDictionary *contactsPinyinDic;//联系人分级字典(用于显示的数据)

@property(nonatomic,strong)NSMutableArray *indexArray;//索引数组

@property(nonatomic,assign)BOOL isDeleteFriend;//是否是删除好友操作,设置布尔值的原因是防止服务器无故刷新数据

@property(nonatomic,assign)BOOL isShowMenu;//当前菜单是否是展示状态.

@property(nonatomic,strong)UserInformationView *userInformationView;//个人菜单

@property(nonatomic,strong)UIView *shadeView;//遮盖View;

@property(nonatomic,strong)UIImage *menuImage;//菜单图片

@property(nonatomic,strong)UIBarButtonItem *headerBarButtonItem;//头像左按钮

@property(nonatomic,strong)UIBarButtonItem *closeMenuBarButtonItem;//关闭图片左按钮

@property(nonatomic,strong)SDUser *user;

@end

@implementation SDContactsVC

-(instancetype)init{

    if (self = [super init]) {
        
        self.user = [SDUser defaulUser];
        
        [[SDXmppManager defaulManager].roster addDelegate:self delegateQueue:dispatch_get_main_queue()];
        [[SDXmppManager defaulManager].vCardAvatarModule addDelegate:self delegateQueue:dispatch_get_main_queue()];
        [[SDXmppManager defaulManager].vCardTempModule addDelegate:self delegateQueue:dispatch_get_main_queue()];
        
        
    }

    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.isDeleteFriend = NO;

    
    [self loadContactsList];
    [self loadUserInformationView];
    [self loadNavigationView];
    [self addLeftBarButtonItem];
    [self addLeftCloseBarButtonItem];
    
    //初始化好友数组
    self.indexArray = [NSMutableArray arrayWithCapacity:16];
    [self.indexArray addObject:@""];

    
    //添加新的好友的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addNewContactAction) name:AddNewContectMessage object:nil];
    
    //好友上下线
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(contactIsAvailable) name:ContactIsAvailable object:nil];

}


-(void)viewWillAppear:(BOOL)animated{

    [super viewWillAppear:animated];
    //修改状态栏显示状态
    [[UIApplication sharedApplication]setStatusBarHidden:NO];
    

    [self reloaList];
}


-(void)loadNavigationView{
    
    self.navigationItem.title = @"好友列表";
    self.navigationController.navigationBar.barTintColor = SDcolor(21, 21, 21);
    [self.navigationController.navigationBar setTitleTextAttributes:
     
     @{NSFontAttributeName: [UIFont fontWithName:@"Helvetica-Bold" size:18],
       
       NSForegroundColorAttributeName:[UIColor whiteColor]}];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"刷新" style:UIBarButtonItemStylePlain target:self action:@selector(reloaList)];
    
    [self.navigationItem.rightBarButtonItem setTitleTextAttributes:@{NSFontAttributeName: [UIFont fontWithName:@"Helvetica-Bold" size:17],
                                                                     
                                                                     NSForegroundColorAttributeName:[UIColor whiteColor]} forState:UIControlStateNormal];
    
    
}

//由于头像加载的问题,所以加载leftBarButtonItem需要单独拿出来
-(void)addLeftBarButtonItem{

    UIImage *image;
    if (!self.menuImage) {
        image = [self reSizeImage:[UIImage imageNamed:@"SDBundle.bundle/头像.png"] toSize:CGSizeMake(36, 36)];
        UIButton *leftBarButton = [UIButton buttonWithType:UIButtonTypeCustom];
        leftBarButton.frame = CGRectMake(0, 4, 36, 36);
        [leftBarButton setImage:image forState:UIControlStateNormal];
        [leftBarButton addTarget:self action:@selector(pushUserInformationView) forControlEvents:UIControlEventTouchUpInside];
        leftBarButton.layer.cornerRadius =18;
        leftBarButton.layer.masksToBounds = YES;
        self.headerBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftBarButton];
        self.navigationItem.leftBarButtonItem = self.headerBarButtonItem;
    }else{
    
        image = [self reSizeImage:self.menuImage toSize:CGSizeMake(36, 36)];
        UIButton *leftBarButton = [UIButton buttonWithType:UIButtonTypeCustom];
        leftBarButton.frame = CGRectMake(0, 4, 36, 36);
        [leftBarButton setImage:image forState:UIControlStateNormal];
        [leftBarButton addTarget:self action:@selector(pushUserInformationView) forControlEvents:UIControlEventTouchUpInside];
        leftBarButton.layer.cornerRadius =18;
        leftBarButton.layer.masksToBounds = YES;
        self.headerBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftBarButton];
    }

    
   
}

-(void)addLeftCloseBarButtonItem{

    UIImage *closeImage = [self reSizeImage:[UIImage imageNamed:@"SDBundle.bundle/关闭.png"] toSize:CGSizeMake(30, 30)];
    UIButton *closeBarButton = [UIButton buttonWithType:UIButtonTypeCustom];
    closeBarButton.frame = CGRectMake(0, 7, 30, 30);
    [closeBarButton setImage:closeImage forState:UIControlStateNormal];
    [closeBarButton addTarget:self action:@selector(pushUserInformationView) forControlEvents:UIControlEventTouchUpInside];
    self.closeMenuBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:closeBarButton];


}

-(void)reloaList{
    
    self.isDeleteFriend = NO;
    
    [[SDXmppManager defaulManager].roster fetchRoster];
    
    [self networkingWithContactsArray];
    
}

#pragma mark ---UITableView ----

//初始化好友列表
-(void)loadContactsList{
    
    self.contactsList = [[UITableView alloc]initWithFrame:CGRectMake(0, 64, KmainWidth, KmainHight-64) style:UITableViewStyleGrouped];
    
    self.contactsList.delegate = self;
    
    self.contactsList.dataSource = self;
    
    self.contactsList.separatorStyle = NO;
    
    self.contactsList.sectionIndexBackgroundColor = [UIColor clearColor];
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    [self.contactsList registerNib:[UINib nibWithNibName:@"ContactCell" bundle:nil] forCellReuseIdentifier:@"ContactCell"];
    [self.contactsList registerNib:[UINib nibWithNibName:@"FunctionCell" bundle:nil] forCellReuseIdentifier:@"FunctionCell"];
    
    [self.view addSubview:self.contactsList];
    
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return self.indexArray.count;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (section == 0) {
        return 1;
    }else{
        
        NSMutableArray *sectionArray =self.contactsPinyinDic[self.indexArray[section]];
        
        return sectionArray.count;
        
        
    }
    
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    

    if (indexPath.section == 0) {
        
        FunctionCell *cell = [tableView dequeueReusableCellWithIdentifier:@"FunctionCell" forIndexPath:indexPath];
        
        cell.iconsImageView.image = [UIImage imageNamed:@"SDBundle.bundle/新的朋友.png"];
        
        cell.functionNameLabel.text = [NSString stringWithFormat:@"  新的朋友"];
        
        if ([SDUser defaulUser].addFriendArray.count !=0) {
            
            cell.messageNumberLabel.hidden = NO;
            cell.messageNumberLabel.layer.cornerRadius = 10;
            cell.messageNumberLabel.layer.masksToBounds = YES;
            cell.messageNumberLabel.text = [NSString stringWithFormat:@"%ld",[SDUser defaulUser].addFriendArray.count];

        }else{
        
            cell.messageNumberLabel.hidden = YES;
        
        }
        
        cell.selectionStyle = UITableViewCellSeparatorStyleNone;

         return cell;
        
        
    }else{
        
        ContactCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ContactCell" forIndexPath:indexPath];
        
        NSMutableArray *sectionArray =self.contactsPinyinDic[self.indexArray[indexPath.section]];
        
        SDContactModel *contact =sectionArray[indexPath.row];
        
        if (contact.vCard.photo == nil) {
            cell.iconsImageView.image = [UIImage imageNamed:@"SDBundle.bundle/头像.png"];

        }else{
        
            cell.iconsImageView.image = [UIImage imageWithData:contact.vCard.photo];

        }

        
        cell.contactNameLabel.text = contact.vCard.nickname;
        
        if (contact.isAvailable) {
            
            cell.stateImage.image = [UIImage imageNamed:@"SDBundle.bundle/在线.png"];
            cell.stateLabel.text = @"在线";
            
        }else{
        
            cell.stateImage.image = [UIImage imageNamed:@"SDBundle.bundle/离线.png"];
            cell.stateLabel.text = @"离线";
        
        }
        
        cell.selectionStyle = UITableViewCellSeparatorStyleNone;
        
        return cell;
    }
    

    
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 60.0;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    
    if (section== 0) {
        
        return 5.0f;
        
    }else{
        return 20.0;
    }
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    
    return 1.0;
    
}

//跳转到对应的页面中去
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == 0) {
        SDAddContactVC *addContactVC = [[SDAddContactVC alloc]init];
        
        [self.navigationController pushViewController:addContactVC animated:YES];
        
    }else{
        
        SDChatVC *chatVC = [[SDChatVC alloc]init];
        
        NSMutableArray *sectionArray =self.contactsPinyinDic[self.indexArray[indexPath.section]];
        
        SDContactModel *contact =sectionArray[indexPath.row];

        chatVC.navigationItem.title = contact.vCard.nickname;
        chatVC.chatToPeople = contact;
        
        [self.navigationController pushViewController:chatVC animated:YES];
        
    }
    
    
    
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    UILabel *titleLable = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, KmainWidth, 20)];
    
    titleLable.text = [NSString stringWithFormat:@"  %@",self.indexArray[section]];
    
    titleLable.font = [UIFont systemFontOfSize:15];
    
    titleLable.tintColor = [UIColor lightGrayColor];
    
    return titleLable;
    
}


//左滑删除
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (indexPath.section>0) {
        
        return YES;
        
    }else{
        
        return NO;
        
    }
    
}
- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return @"删除";
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 从数据源中删除
    NSMutableArray *sectionArray =self.contactsPinyinDic[self.indexArray[indexPath.section]];
    SDContactModel *contact =sectionArray[indexPath.row];

    UIAlertController *alertView =[UIAlertController alertControllerWithTitle:@"确认删除" message:[NSString stringWithFormat:@"确认要删除好友 %@ ?",contact.vCard.nickname] preferredStyle:UIAlertControllerStyleAlert];
    
    __weak typeof(self)temp = self;
    UIAlertAction *deleteAction = [UIAlertAction actionWithTitle:@"确认删除" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        
        [temp.user.contactsArray removeObject:(NSString *)sectionArray[indexPath.row]];
        
        XMPPJID *jid =contact.jid;
        [sectionArray removeObjectAtIndex:indexPath.row];
        
        if (sectionArray.count == 0) {
            
            [temp.contactsPinyinDic removeObjectForKey:temp.indexArray[indexPath.section]];
            
            [temp.indexArray removeObjectAtIndex:indexPath.section];
            
            [tableView reloadData];
            
            
        }else{
            
            [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
            
        }
        temp.isDeleteFriend = YES;
        
        
        [[SDXmppManager defaulManager].roster removeUser:jid];
        
    }];
    
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    
    [alertView addAction:deleteAction];
    [alertView addAction:cancelAction];
    
    [self presentViewController:alertView animated:YES completion:nil];
    
}


//快速索引
-(NSArray<NSString *> *)sectionIndexTitlesForTableView:(UITableView *)tableView{
    
    return self.indexArray;
    
}

-(NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index{

    return index;
}



#pragma mark ----获取好友数据----

-(void)xmppRosterDidEndPopulating:(XMPPRoster *)sender{

    [self networkingWithContactsArray];

}

//获取好友信息的时候
-(void)xmppRoster:(XMPPRoster *)sender didReceiveRosterItem:(DDXMLElement *)item{
    
    NSLog(@"%@",[[item attributeForName:@"subscription"] stringValue]);

    //互为好友
    if ([[[item attributeForName:@"subscription"] stringValue] isEqualToString:@"both"]||[[[item attributeForName:@"subscription"] stringValue] isEqualToString:@"from"]||[[[item attributeForName:@"subscription"] stringValue] isEqualToString:@"to"]) {
        
        NSString *SJid = [[item attributeForName:@"jid"] stringValue];
        
        //把字符串类型的JID转换成XMPPJID
        XMPPJID *jid = [XMPPJID jidWithString:SJid];
        
        if (!self.isDeleteFriend) {
            
            BOOL isExist = NO;
            
            for (SDContactModel *contact in self.user.contactsArray) {
                
                if ([contact.jid.user isEqualToString:jid.user]) {
                    
                    isExist = YES;
                    
                }
                
            }
            
            if (!isExist) {
                //添加数据
                XMPPvCardTemp *vCard =  [[SDXmppManager defaulManager].vCardTempModule vCardTempForJID:jid shouldFetch:YES];
                
                [[SDXmppManager defaulManager].vCardTempModule fetchvCardTempForJID:jid ignoreStorage:YES];
                
                SDContactModel *contact =[[SDContactModel alloc]init];
                contact.jid = jid;
                contact.vCard =vCard;
                contact.isAvailable = NO;
                
                [self.user.contactsArray addObject:contact];
                
                
            }
            
        }

    }
    
    //删除好友操作
    if ([[[item attributeForName:@"subscription"] stringValue] isEqualToString:@"remove"]) {
        
        NSString *SJid = [[item attributeForName:@"jid"] stringValue];
        
        //把字符串类型的JID转换成XMPPJID
        XMPPJID *jid = [XMPPJID jidWithString:SJid];
        SDContactModel *contact;
        for (SDContactModel *obj in self.user.contactsArray) {
            
            if ([obj.jid.user isEqualToString:jid.user]) {
                
                contact = obj;
                
            }
            
        }

        [self.user.contactsArray removeObject:contact];
        
        [self networkingWithContactsArray];
        
    }

}


//整理好友数据
-(void)networkingWithContactsArray{
    
    self.contactsPinyinDic = [[NSMutableDictionary alloc]init];
    
    for (SDContactModel *contact in self.user.contactsArray) {
        
        NSString *firstWord = [self transform:contact.vCard.nickname];

        
        if (self.contactsPinyinDic[firstWord] ==nil) {
            
            //如果联系人字典数组中没有该分组,那么就初始化一个分组数组,然后存储.
            NSMutableArray *sectionArray =[NSMutableArray  arrayWithCapacity:16];
            
            [sectionArray addObject:contact];
            
            [self.contactsPinyinDic setValue:sectionArray forKey:firstWord];
            
        }else{
            
            NSMutableArray *sectionArray =self.contactsPinyinDic[firstWord];
            
            [sectionArray addObject:contact];
            
        }
        
        
    }
    
    //创建索引数组,并且进行排序.
    self.indexArray = [NSMutableArray arrayWithArray:self.contactsPinyinDic.allKeys];
    
    [self.indexArray addObject:@""];//添加一个空的字符串,用于菜单分组
    
    for (int i = 0; i<self.indexArray.count; i++) {
        
        for (int j = 0; j<i; j++) {
            
            if (self.indexArray[j]>self.indexArray[i]) {
                
                NSString *objString = self.indexArray[j];
                self.indexArray[j] =  self.indexArray[i];
                self.indexArray[i] = objString;
                
            }
        }
        
    }
    
    //索引数组移动#号到最后.
    if ([self isIncludeWithJing]) {
        
        [self.indexArray removeObject:@"#"];
        
        [self.indexArray addObject:@"#"];
    }
    
    [self.contactsList reloadData];
}


//判断索引数组中是否含有@"#",如果含有的话,我们准备移动它到最后的位置.

-(BOOL)isIncludeWithJing{
    
    for (NSString *obj in self.indexArray) {
        
        if ([obj isEqualToString:@"#"]) {
            return YES;
        }
    }
    return NO;
    
}


#pragma mark --- 个人菜单 ---
-(void)loadUserInformationView{
    self.isShowMenu = NO;
    self.userInformationView = [[UserInformationView alloc]initWithFrame:CGRectMake(60-KmainWidth, 64, KmainWidth-60, KmainHight-64)];
    
    self.userInformationView.delegate = self;
    
    [self.view addSubview:self.userInformationView];
    //添加轻扫手势
    UISwipeGestureRecognizer *swp = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(popUserInformationView)];
    swp.direction =UISwipeGestureRecognizerDirectionLeft;
    [self.view addGestureRecognizer:swp];
    
    //初始化遮罩View
    self.shadeView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    self.shadeView.backgroundColor = [UIColor colorWithRed:125.0/255.0 green:125.0/255.0 blue:125.0/255.0 alpha:0.5];
    
}

-(void)pushUserInformationView{
    
    __weak typeof(self)temp = self;
    [UIView transitionWithView:self.userInformationView duration:0.3 options:UIViewAnimationOptionCurveEaseIn animations:^{
        
        if (temp.isShowMenu) {
            
            temp.userInformationView.frame = CGRectMake(60-KmainWidth, 64, KmainWidth-60, KmainHight-64);
            temp.isShowMenu = !temp.isShowMenu;
            
        }else{
            
            temp.isShowMenu = !temp.isShowMenu;
            temp.userInformationView.frame = CGRectMake(0, 64, KmainWidth-60, KmainHight-64);
            
        }
        
    } completion:^(BOOL finished) {
        
        if (finished && temp.isShowMenu) {
            
            //重新加载所有数据,头像数据过大,所以我们只获取已经获取的即可.
            [temp.userInformationView reloadAllData];
            self.userInformationView.headerImageView.image = self.menuImage;
            
            //添加遮罩View
            [temp.view insertSubview:temp.shadeView belowSubview:temp.userInformationView];
            temp.navigationItem.leftBarButtonItem = temp.closeMenuBarButtonItem;
            
        }else{
            
            [temp.shadeView removeFromSuperview];
            
            temp.navigationItem.leftBarButtonItem = temp.headerBarButtonItem;
            
        }
    }];
    
    
}


-(void)popUserInformationView{
    
    self.isShowMenu = NO;
    __weak typeof(self)temp = self;
    [UIView transitionWithView:self.userInformationView duration:0.3 options:UIViewAnimationOptionCurveEaseOut animations:^{
        
        temp.userInformationView.frame = CGRectMake(60-KmainWidth, 64, KmainWidth-60, KmainHight-64);
    } completion:^(BOOL finished) {
        
        //移除遮罩
        [temp.shadeView removeFromSuperview];
        
        temp.navigationItem.leftBarButtonItem = self.headerBarButtonItem;
        
    }];
    
}



//点击退出登录的时候
-(void)logoutUser{
    
    //清除所有数据
    [self.user.contactsArray removeAllObjects];
    
    [[SDUser defaulUser].addFriendArray removeAllObjects];
    //关闭菜单栏
    [self popUserInformationView];
    
    
    UIAlertController *alerView =[UIAlertController alertControllerWithTitle:@"确认退出" message:@"确定要退出当前账号?" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *alertAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    
    [alerView addAction: alertAction];
    
    UIAlertAction *alertAction1 = [UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        
        SDLoginVC *vc = [[SDLoginVC alloc]initWithMainVC:[[UIViewController alloc]init] viewControllerType:RollImageLaunchViewController];
        
        vc.rollImageName = @"滚动背景.png";
        vc.hideEndButton = YES;
        
        [self presentViewController:vc animated:YES completion:nil];

    }];
    
    [alerView addAction: alertAction1];
    
    [self presentViewController:alerView animated:YES completion:nil];
    

}


-(void)clickHeaderView{

    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    
    __weak typeof(self)temp = self;
    UIAlertAction *alertAction1 = [UIAlertAction actionWithTitle:@"从相册选择" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        [temp showPhotoLibraryVC];

    }];
    
    [alertVC addAction: alertAction1];
    
    
    UIAlertAction *alertAction2 = [UIAlertAction actionWithTitle:@"拍照" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        
        [temp showCameraPickerVC];
    }];
    
    [alertVC addAction: alertAction2];
    
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    
    [alertVC addAction: cancelAction];
    
    [self presentViewController:alertVC animated:YES completion:nil];

}




#pragma mark ---调取相机---
-(void)showCameraPickerVC{


    //设置调用类型为相机
    UIImagePickerControllerSourceType  sourceType = UIImagePickerControllerSourceTypeCamera;
    
    if (![UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera]) {
        
        NSLog(@"本设备未发现摄像头!");
        
        return;
        
    }
    
    UIImagePickerController *pickerController = [[UIImagePickerController alloc]init];
    
    pickerController.sourceType = sourceType;
    
    pickerController.delegate = self;
    
    pickerController.allowsEditing = YES;//设置是否可以进行编辑
    
    [[UIApplication sharedApplication]setStatusBarHidden:YES];
    [self showDetailViewController:pickerController sender:nil];

}


-(void)showPhotoLibraryVC{

    UIImagePickerControllerSourceType  sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    UIImagePickerController *pickerController = [[UIImagePickerController alloc]init];
    
    pickerController.sourceType = sourceType;
    
    pickerController.delegate = self;
    
    pickerController.allowsEditing = YES;
    
    [self showDetailViewController:pickerController sender:nil];

}


-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    
    NSString *type = [info objectForKey:UIImagePickerControllerMediaType];
    
    //当选择的类型是图片
    if ([type isEqualToString:@"public.image"])
    {
        UIImage* image = [info objectForKey:@"UIImagePickerControllerEditedImage"];
        XMPPvCardTemp *vCard = [SDXmppManager defaulManager].vCardTempModule.myvCardTemp;

        NSData *data;
        if (UIImagePNGRepresentation(image) == nil)
        {
            UIImage *headerimage = [self reSizeImage:image toSize:CGSizeMake(100, 100)];

            data = UIImageJPEGRepresentation(headerimage, 1.0);
            vCard.photo = data;

        }
        else
        {
            UIImage *headerimage = [self reSizeImage:image toSize:CGSizeMake(100, 100)];
            data = UIImagePNGRepresentation(headerimage);
            vCard.photo = data;

        }
        
        [[SDXmppManager defaulManager].vCardTempModule updateMyvCardTemp:vCard];
        
        [picker dismissViewControllerAnimated:YES completion:nil];
    }
    
}
#pragma mark ----用户以及好友的信息发生改变的时候----
- (void)xmppvCardTempModule:(XMPPvCardTempModule *)vCardTempModule
        didReceivevCardTemp:(XMPPvCardTemp *)vCardTemp
                     forJID:(XMPPJID *)jid {
    // 打印用户信息
    XMPPvCardTemp *temp = [[SDXmppManager defaulManager].vCardCoreDataStorage vCardTempForJID:jid xmppStream:[SDXmppManager defaulManager].stream];
    
    NSLog(@"ID : %@ ---- 名称 : %@",jid,temp.nickname);
    
    if ([jid.user isEqual:[SDUser defaulUser].jid.user]) {
        
        [SDUser defaulUser].vCard = vCardTemp;

        [self.userInformationView reloadAllData];
        
    }else{
    
        for (NSString * key in self.contactsPinyinDic) {
            
            NSMutableArray *array = [NSMutableArray arrayWithArray:self.contactsPinyinDic[key]];
            
            for (SDContactModel *model in array) {
                
                if ([model.jid isEqual:jid]) {
                    
                    model.vCard =vCardTemp;
                    
                }
                
                
            }
    
          }
        
        //刷新页面
        [self networkingWithContactsArray];
    }
}

- (void)xmppvCardAvatarModule:(XMPPvCardAvatarModule *)vCardTempModule
              didReceivePhoto:(UIImage *)photo
                       forJID:(XMPPJID *)jid{
    
    
    if ([jid.user isEqual:[SDUser defaulUser].jid.user]) {
        
        //登录本身图片的改变
        self.menuImage = photo;
        self.user.headerImage = photo;
        [self addLeftBarButtonItem];
        self.userInformationView.headerImageView.image = photo;
        [self addNewHeaderBarItem];
        
    }else{
    
        //好友头像图片的改变
        for (NSString * key in self.contactsPinyinDic) {
            
            NSMutableArray *array = [NSMutableArray arrayWithArray:self.contactsPinyinDic[key]];
            
            for (SDContactModel *model in array) {
                
                if ([model.jid isEqual:jid]) {
                    
                    
                    
                    NSData *imgData;
                    if (UIImagePNGRepresentation(photo) == nil) {
                        
                        imgData = UIImageJPEGRepresentation(photo, 1);
                        model.vCard.photo =imgData;
                    } else {
                        
                        imgData = UIImagePNGRepresentation(photo);
                        model.vCard.photo =imgData;

                    }
                    
                }
                
                
            }

        }
    
        //刷新页面
        [self reloaList];
    
    }

}




-(void)addNewHeaderBarItem{

    if (_isShowMenu == NO) {
        
        self.navigationItem.leftBarButtonItem = self.headerBarButtonItem;
        
    }


}

#pragma mark ---好友请求---
//添加新的联系人的通知
-(void)addNewContactAction{
    
    NSIndexPath *indexPath=[NSIndexPath indexPathForRow:0 inSection:0];
    
    //判断当前是否是在列表的最上端
    NSArray *indexPathArray = [self.contactsList indexPathsForVisibleRows];
    for (NSIndexPath *obj in indexPathArray) {
        if ([obj isEqual:indexPath]) {
            [self.contactsList reloadRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath,nil] withRowAnimation:UITableViewRowAnimationNone];
        }
    }
    
}


#pragma mark ----好友上下线通知方法 -----

-(void)contactIsAvailable{

    [self reloaList];

}


#pragma mark ----基础小功能---
//截取首字母并且大写
-(NSString *)transform:(NSString *)chinese{
    
    if (chinese == nil ||[chinese isEqualToString:@""]) {
        
        return @"#";
        
    }
    
    NSMutableString *pinyin = [chinese mutableCopy];
    CFStringTransform((__bridge CFMutableStringRef)pinyin, NULL, kCFStringTransformMandarinLatin, NO);
    CFStringTransform((__bridge CFMutableStringRef)pinyin, NULL, kCFStringTransformStripCombiningMarks, NO);
    
    NSString *subString = [[pinyin uppercaseString] substringWithRange:NSMakeRange(0, 1)];
    
    if ([self isPureInt:subString] || [self isPureFloat:subString]) {
        
        return  @"#";
    }
    
    return subString;
}

//判断是否为整型：
- (BOOL)isPureInt:(NSString*)string{
    NSScanner* scan = [NSScanner scannerWithString:string];
    int val;
    return [scan scanInt:&val] && [scan isAtEnd];
}
//判断是否为浮点型：
- (BOOL)isPureFloat:(NSString*)string{
    NSScanner* scan = [NSScanner scannerWithString:string];
    float val;
    return[scan scanFloat:&val] && [scan isAtEnd];
}

//修改图片尺寸
- (UIImage *)reSizeImage:(UIImage *)image toSize:(CGSize)reSize{
    
    UIGraphicsBeginImageContext(CGSizeMake(reSize.width, reSize.height));
    
    [image drawInRect:CGRectMake(0, 0, reSize.width, reSize.height)];
    
    UIImage *reSizeImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return reSizeImage;
    
}

//释放
-(void)dealloc{

    [[NSNotificationCenter defaultCenter] removeObserver:self];

}




@end
