//
//  SDChatVC.m
//  SDChatDemo
//
//  Created by songjc on 16/11/30.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "SDChatVC.h"
#import "SDChatCell.h"
#import "SDChatModel.h"
#import "InputView.h"
#import "SDXmppManager.h"
#import <AVFoundation/AVFoundation.h>
#import "TranscribeVoiceView.h"
#import "XMPPMessage.h"
#import "SDUser.h"
#import "XMPPvCardTemp.h"
#define kRecordAudioFile @"myRecord.wav"


@interface SDChatVC ()<UITableViewDelegate,UITableViewDataSource,UITextViewDelegate,XMPPStreamDelegate,AVAudioRecorderDelegate,AVAudioPlayerDelegate,SDChatCellDelegate>

@property(nonatomic,strong)UITableView *chatTableView;//聊天界面

@property(nonatomic,strong)InputView *inputView;

@property(nonatomic,strong)NSMutableArray *chatDataArray;//聊天记录数组

// 录音机
@property (nonatomic, strong) AVAudioRecorder *audioRecorder;
// 音频播放器
@property (nonatomic, strong) AVAudioPlayer *audioPlayer;

//输入语音提示框.
@property(nonatomic,strong)TranscribeVoiceView *transcribeVoiceView;

@end

@implementation SDChatVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor orangeColor];
    
    [self loadNavigationView];
    
    [self loadChatTableView];
    
    [self loadInputView];
    
    [self setAudioSession];
    
    //添加代理
    [[SDXmppManager defaulManager].stream addDelegate:self delegateQueue:dispatch_get_main_queue()];
    
    //更新聊天记录信息
    [self reloadMessage];
    
}

//展现聊天记录
-(void)reloadMessage{
    
    NSManagedObjectContext *context = [SDXmppManager defaulManager].messageContext;
    
#pragma mark----直接一个 fet 下面全都出来了----
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    //这里面要填的是XMPPARChiver的coreData实例类型
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"XMPPMessageArchiving_Message_CoreDataObject" inManagedObjectContext:context];
    [fetchRequest setEntity:entity];
    // Specify criteria for filtering which objects to fetch
    
    //对取到的数据进行过滤,传入过滤条件.
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"streamBareJidStr == %@ AND bareJidStr == %@", [SDXmppManager defaulManager].stream.myJID.bare,self.chatToPeople.jid.bare];
    [fetchRequest setPredicate:predicate];
    // Specify how the fetched objects should be sorted
    
    //设置排序的关键字
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"timestamp"
                                                                   ascending:YES];
    [fetchRequest setSortDescriptors:[NSArray arrayWithObjects:sortDescriptor, nil]];
    
    NSError *error = nil;
    NSArray *fetchedObjects = [context executeFetchRequest:fetchRequest error:&error];
    if (fetchedObjects == nil) {
        
        //完成之后干什么?
        NSLog(@"和此人的激情交谈");
        
    }
    
    /********获取和这个人所有的聊天记录***************/
    
    //清空聊天数组中的消息
    [self.chatDataArray removeAllObjects];
    
    //将新的聊天记录添加到数组中
    self.chatDataArray = [NSMutableArray arrayWithArray:fetchedObjects];
    
    NSLog(@"%ld",self.chatDataArray.count);
    
    //刷新UI
    [self.chatTableView reloadData];
    
    //滚动到tableView最底层
    if (self.chatDataArray.count != 0) {
        [self.chatTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:self.chatDataArray.count - 1] atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
    }

    
}


-(void)loadNavigationView{
    
    self.navigationController.navigationBar.barTintColor = SDcolor(21, 21, 21);

    [self.navigationController.navigationBar setTitleTextAttributes:
     
     @{NSFontAttributeName: [UIFont fontWithName:@"Helvetica-Bold" size:18],
       
       NSForegroundColorAttributeName:[UIColor whiteColor]}];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(popVC)];
    
    
    [self.navigationItem.leftBarButtonItem setTitleTextAttributes:@{NSFontAttributeName: [UIFont fontWithName:@"Helvetica-Bold" size:17],
                                                                    NSForegroundColorAttributeName:[UIColor whiteColor]} forState:UIControlStateNormal];
    
    [self.navigationItem.rightBarButtonItem setTitleTextAttributes:@{NSFontAttributeName: [UIFont fontWithName:@"Helvetica-Bold" size:17],
                                                                     
                                                                     NSForegroundColorAttributeName:[UIColor whiteColor]} forState:UIControlStateNormal];
    
    
}

-(void)popVC{
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

//聊天列表
-(void)loadChatTableView{

    self.chatTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 64, KmainWidth, KmainHight-114) style:UITableViewStyleGrouped];
    
    self.chatTableView.backgroundColor = ChatViewBackColor;
    
    self.chatTableView.delegate = self;
    
    self.chatTableView.dataSource = self;
    
    self.chatTableView.separatorStyle = NO;
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    [self.chatTableView registerClass:[SDChatCell class] forCellReuseIdentifier:@"SDChatCell"];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(setKeyboardHide)];
    
    [self.chatTableView addGestureRecognizer:tap];
    
    [self.view addSubview:self.chatTableView];

}


//输入view
-(void)loadInputView{

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyBoardShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardHide:) name:UIKeyboardWillHideNotification object:nil];
    
    self.inputView = [[InputView alloc]initWithFrame:CGRectMake(0, KmainHight-50, KmainWidth, 50)];
    
    self.inputView.inputTextView.delegate = self;
    
    [self.inputView.sendButton addTarget:self action:@selector(sendMessage) forControlEvents:UIControlEventTouchUpInside];
    
    [self.inputView.sendSoundButton addTarget:self action:@selector(transcribeVoiceAcrion) forControlEvents:UIControlEventTouchDown];
    
    [self.inputView.sendSoundButton addTarget:self action:@selector(sendVoiceAcrion) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.inputView];

}


//点击tableView让键盘收起
-(void)setKeyboardHide{
    
    if ([self.inputView.inputTextView isFirstResponder]) {
        
        [self.inputView.inputTextView resignFirstResponder];
    }
    
}

#pragma mark ---tableViewDataSoure---

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{

    return self.chatDataArray.count;

}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return 1;

}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    SDChatCell *cell = [tableView dequeueReusableCellWithIdentifier:@"SDChatCell"];
    
    cell.delegate = self;
    
    cell.selectionStyle  = UITableViewCellSeparatorStyleNone;
    
    XMPPMessageArchiving_Message_CoreDataObject *message = self.chatDataArray[indexPath.section];
    
    SDChatModel *model = [[SDChatModel alloc]init];
    
    model.isSend = message.isOutgoing;
    
    model.message = message.body;
    
    //头像的设置
    if (message.isOutgoing) {
        
        model.headerImage = [SDUser defaulUser].headerImage;
        
    }else{
    
        model.headerImage = [UIImage imageWithData:_chatToPeople.vCard.photo];
    
    }
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    
    [formatter setDateFormat:@"HH:mm"];
    
    NSString *dateTime = [formatter stringFromDate:message.timestamp];
    
    model.messageTime =dateTime;
    
    model.msg =message;

    [cell refreshCell:model];
    
    return cell;


}



//计算cell的高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    
    XMPPMessageArchiving_Message_CoreDataObject *message = self.chatDataArray[indexPath.section];

    //计算字符串高度
    CGFloat height =[self  textHight:message.body];
    
    //5是空白区域的高度
    return height+10 ;
    
}

-(CGFloat )textHight:(NSString *)string{
    
    CGRect rect = [string boundingRectWithSize:CGSizeMake(KmainWidth/14*9, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17]} context:nil];
    
    return rect.size.height;
}

//headerView显示时间
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, KmainWidth, 35)];

    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 19, KmainWidth, 25)];
    
    label.textAlignment = NSTextAlignmentCenter;
    
    label.font = [UIFont systemFontOfSize:15];
    
    XMPPMessageArchiving_Message_CoreDataObject *message = self.chatDataArray[section];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    
    [formatter setDateFormat:@"HH:mm"];
    
    NSString *dateTime = [formatter stringFromDate:message.timestamp];
    
    
    label.text = dateTime;
    
    [view addSubview:label];
    
    return view;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{

    return 44.0f;
}

#pragma mark ----发送文字----

//发送一条消息
-(void)sendMessage{
    
    XMPPMessage *message = [XMPPMessage messageWithType:@"chat" to:self.chatToPeople.jid];
    
    [message addBody:self.inputView.inputTextView.text];
    NSXMLElement *receipt = [NSXMLElement elementWithName:@"request" xmlns:@"urn:xmpp:receipts"];
    [message addChild:receipt];
    
    //发送消息
    [[SDXmppManager defaulManager].stream sendElement:message];
    
    //输入框内容设置为空,并且关闭发送按钮的用户交互.
    self.inputView.inputTextView.text = @"";
    
    self.inputView.sendButton.backgroundColor = SDcolor(126, 126, 126);
    
    self.inputView.sendButton.userInteractionEnabled  = NO;

    
}


-(void)xmppStream:(XMPPStream *)sender didSendMessage:(XMPPMessage *)message{
    
    //    tipWithMessage(@"消息发送成功!");
    
    [self reloadMessage];
    
    [self.chatTableView reloadData];

}


-(void)xmppStream:(XMPPStream *)sender didFailToSendMessage:(XMPPMessage *)message error:(NSError *)error{
    
    NSLog(@"消息发送失败!");
    
}


-(void)xmppStream:(XMPPStream *)sender didReceiveMessage:(XMPPMessage *)message{
    
        NSXMLElement *request = [message elementForName:@"request"];
    if (request)
    {
        if ([request.xmlns isEqualToString:@"urn:xmpp:receipts"])//消息回执
        {
            //组装消息回执
            XMPPMessage *msg = [XMPPMessage messageWithType:[message attributeStringValueForName:@"type"] to:message.from elementID:[message attributeStringValueForName:@"id"]];
            NSXMLElement *recieved = [NSXMLElement elementWithName:@"received" xmlns:@"urn:xmpp:receipts"];
            [msg addChild:recieved];
            
            //发送回执
            [[SDXmppManager defaulManager].stream  sendElement:msg];
        }
    }else
    {
        NSXMLElement *received = [message elementForName:@"received"];
        if (received)
        {
            if ([received.xmlns isEqualToString:@"urn:xmpp:receipts"])//消息回执
            {
                //发送成功
                NSLog(@"message send success!");
            }
        }
    }
    
    
    
    [self reloadMessage];
    
}



#pragma mark ---发送语音---
- (AVAudioRecorder *)audioRecorder {
    if (!_audioRecorder) {
        NSURL *url = [self getSavePath];
        NSDictionary *setting = [self getAudioSetting];
        NSError *error = nil;
        _audioRecorder = [[AVAudioRecorder alloc] initWithURL:url settings:setting error:&error];
        _audioRecorder.delegate = self;
        if (error) {
            NSLog(@"创建录音机对象时发生错误,错误信息:%@",error.localizedDescription);
            return nil;
        }
    }
    return _audioRecorder;
}
// 设置音频保存路径
- (NSURL *)getSavePath {
    NSString *urlStr = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    urlStr = [urlStr stringByAppendingPathComponent:kRecordAudioFile];
    NSURL *url = [NSURL URLWithString:urlStr];
    
    return url;
}

// 录音文件设置
- (NSDictionary *)getAudioSetting {
    NSMutableDictionary *dicM = [NSMutableDictionary dictionary];
    // 设置录音格式
    [dicM setObject:@(kAudioFormatLinearPCM) forKey:AVFormatIDKey];
    // 设置录音采样率,8000是电话采样率,对于一般录音已经够了
    [dicM setObject:@(8000) forKey:AVSampleRateKey];
    // 设置通道,这里采用单声道
    [dicM setObject:@(1) forKey:AVNumberOfChannelsKey];
    // 每个采样点位数,分别为8,16,24,32
    [dicM setObject:@(8) forKey:AVLinearPCMBitDepthKey];
    // 是否使用浮点数采样
    [dicM setObject:@(YES) forKey:AVLinearPCMIsFloatKey];
    // ...其他设置
    return dicM;
}


/**
 *  设置音频会话
 注意:一定要添加音频会话,不然真机上的录音时间不对,并且不能进行播放音频
 */
-(void)setAudioSession{
    AVAudioSession *audioSession=[AVAudioSession sharedInstance];
    //设置为播放和录音状态，以便可以在录制完之后播放录音
    [audioSession setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
    [audioSession setActive:YES error:nil];
    
    NSError *audioError = nil;
    BOOL success = [audioSession overrideOutputAudioPort:AVAudioSessionPortOverrideSpeaker error:&audioError];
    if(!success){
        NSLog(@"error doing outputaudioportoverride - %@", [audioError localizedDescription]);
                 }
}


-(void)transcribeVoiceAcrion{

    TranscribeVoiceView *transcribeVoiceView = [[TranscribeVoiceView alloc]initWithFrame:CGRectMake(0, 0, 120 , 130)];
    self.transcribeVoiceView = transcribeVoiceView;
    CGFloat centerX = [UIScreen mainScreen].bounds.size.width / 2.0;
    CGFloat centerY = [UIScreen mainScreen].bounds.size.height / 2.0;
    self.transcribeVoiceView.center = CGPointMake(centerX, centerY);
    [self.view addSubview:self.transcribeVoiceView];
    
    [self.audioRecorder record];

}


-(void)sendVoiceAcrion{


    NSTimeInterval time = self.audioRecorder.currentTime;

    if (time < 1.5) {
        // 时间小于1.5秒不发送,大于1.5秒才发送
        // 停止录音
        [self.audioRecorder stop];
        // 删除录音文件
        [self.audioRecorder deleteRecording];
        
        self.transcribeVoiceView.textLable.text = @"说话时间太短";
        
    } else {
        // 停止录音
        [self.audioRecorder stop];
        
        // 发送语音
        NSString *urlStr = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
        urlStr = [urlStr stringByAppendingPathComponent:kRecordAudioFile];
        NSData *voiceData = [NSData dataWithContentsOfFile:urlStr];
        [self sendVoiceMessageWithData:voiceData bodyType:@"voice" withDuringTime:time];
    }


    
    //移除提示框
    [self.transcribeVoiceView removeFromSuperview];

}


- (void)sendVoiceMessageWithData:(NSData *)data bodyType:(NSString *)type withDuringTime:(NSTimeInterval)time{
    XMPPMessage* message = [[XMPPMessage alloc] initWithType:@"chat" to:self.chatToPeople.jid];
    // 将时间传过去
    NSString *timeStr = [NSString stringWithFormat:@"%f",time];
    [message addAttributeWithName:@"duringTime" stringValue:timeStr];
    [message addBody:type];
    NSXMLElement *receipt = [NSXMLElement elementWithName:@"request" xmlns:@"urn:xmpp:receipts"];
    [message addChild:receipt];
    
    NSString *base64str = [data base64EncodedStringWithOptions:0];
    
    XMPPElement *attachment = [XMPPElement elementWithName:@"attachment" stringValue:base64str];

    
    [message addChild:attachment];
    [[SDXmppManager defaulManager].stream sendElement:message];
    
    
    
}



-(void)tapWithbackView:(SDChatModel *)cellModel{

    
    if ([cellModel.msg.message.body isEqualToString:@"voice"]) {
        
        if (self.audioPlayer.isPlaying) {
            [self.audioPlayer stop];
        }
        
        XMPPElement *node = cellModel.msg.message.children.lastObject;
        // 取出消息的解码
        NSString *base64str = node.stringValue;
        NSData *data = [[NSData alloc]initWithBase64EncodedString:base64str options:0];
        
        self.audioPlayer = [[AVAudioPlayer alloc] initWithData:data error:NULL];
        self.audioPlayer.delegate = self;
        [self.audioPlayer play];
        
    }

}


















#pragma mark ---键盘相关---
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    
    
    return YES;

}

//监控输入框的内容是否为空,如果为空,则不能点击按钮
- (void)textViewDidChange:(UITextView *)textView{
    
    if (textView.text.length != 0 ||![textView.text isEqualToString: @""]) {
        
        self.inputView.sendButton.backgroundColor = [UIColor orangeColor];
        
        self.inputView.sendButton.userInteractionEnabled  = YES;
    }else{
        
        self.inputView.sendButton.backgroundColor = SDcolor(126, 126, 126);
        
        self.inputView.sendButton.userInteractionEnabled  = NO;
        
        
    }
}

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView{

    [textView reloadInputViews];
    
    return YES;

}

- (BOOL)textViewShouldEndEditing:(UITextView *)textView{

    return YES;

}

// 监听键盘弹出
- (void)keyBoardShow:(NSNotification *)noti
{
   
    CGRect rec = [noti.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    // 小于，说明覆盖了输入框
    if ([UIScreen mainScreen].bounds.size.height - rec.size.height < self.inputView.frame.origin.y + self.inputView.frame.size.height)
    {
        // 把我们整体的View往上移动
        CGRect tempRec = self.view.frame;
        tempRec.origin.y = - (rec.size.height);
        self.view.frame = tempRec;
    }
    // 由于可见的界面缩小了，TableView也要跟着变化Frame
    self.chatTableView.frame = CGRectMake(0,rec.size.height+64 , KmainWidth, KmainHight -64- rec.size.height - self.inputView.frame.size.height);
    
    
    
}


// 监听键盘隐藏
- (void)keyboardHide:(NSNotification *)noti
{
    self.view.frame = CGRectMake(0, 0, KmainWidth, KmainHight);
    self.chatTableView.frame = CGRectMake(0, 64, KmainWidth, KmainHight - 64 - self.inputView.frame.size.height);
}


-(void)dealloc{

    [[NSNotificationCenter defaultCenter] removeObserver:self];

}





@end
