//
//  SDContactsVC.h
//  SDChatDemo
//
//  Created by songjc on 16/11/30.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SDContactsVC : UIViewController

//SDContactsVC是一个好友列表的界面

@end
