//
//  SDAddContactVC.h
//  SDChatDemo
//
//  Created by songjc on 16/12/2.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SDAddContactVC : UIViewController

//SDAddContactVC是好友添加通知、好友请求、好友查找的一个页面.


@end
