//
//  SDUser.m
//  SDChatDemo
//
//  Created by songjc on 16/12/5.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "SDUser.h"
#import "SDXmppManager.h"
#import "XMPPvCardTemp.h"
@implementation SDUser
static SDUser *manager;

+(instancetype)defaulUser{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        manager = [[SDUser alloc]init];
        manager.headerImage = [[UIImage alloc]init];
        manager.addFriendArray = [NSMutableArray  arrayWithCapacity:16];
        manager.contactsArray = [NSMutableArray arrayWithCapacity:16];
        
    });
    
    return manager;
    
}

+(void)clearAllData{

    manager.addFriendArray = [NSMutableArray  arrayWithCapacity:16];
    manager.contactsArray = [NSMutableArray arrayWithCapacity:16];

}


@end
