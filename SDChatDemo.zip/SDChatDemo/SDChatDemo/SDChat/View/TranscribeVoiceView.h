//
//  TranscribeVoiceView.h
//  SDChatDemo
//
//  Created by songjc on 16/12/9.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TranscribeVoiceView : UIView

//TranscribeVoiceView是一个关于提示正在录制语音的View;

@property(nonatomic,strong)UIImageView *imgview;

@property(nonatomic,strong)UILabel *textLable;


@end
