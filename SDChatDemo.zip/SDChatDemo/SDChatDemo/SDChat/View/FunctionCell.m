//
//  FunctionCell.m
//  SDChatDemo
//
//  Created by songjc on 16/12/12.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "FunctionCell.h"

@implementation FunctionCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
