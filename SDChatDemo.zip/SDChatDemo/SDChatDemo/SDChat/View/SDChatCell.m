//
//  SDChatCell.m
//  SDChatDemo
//
//  Created by songjc on 16/12/1.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "SDChatCell.h"
#import "SDUser.h"
@implementation SDChatCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        self.headImageView = [[UIImageView alloc] init];
        self.headImageView.layer.cornerRadius = 20.0f;
        self.headImageView.clipsToBounds = YES;
        [self.contentView addSubview:self.headImageView];
        
        self.backView = [[UIImageView alloc] init];
        [self.contentView addSubview:self.backView];
        
        self.contentLabel = [[UILabel alloc] init];
        self.contentLabel.numberOfLines = 0;
        self.contentLabel.font = [UIFont systemFontOfSize:17.0f];
        [self.backView addSubview:self.contentLabel];
        
        self.contentView.backgroundColor = ChatViewBackColor;
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(delegateAction)];
        [self.backView addGestureRecognizer:tap];
        self.backView.userInteractionEnabled = YES;
        
    }
    return self;
}

- (void)refreshCell:(SDChatModel *)model

{

    self.cellModel = model;
    
    // 首先计算文本宽度和高度
    CGRect rec = [model.message boundingRectWithSize:CGSizeMake(KmainWidth/14*9, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : [UIFont systemFontOfSize:17]} context:nil];
    // 气泡
    UIImage *image = nil;
    // 头像
    UIImage *headImage = nil;
    // 模拟左边
    if (!model.isSend)
    {
        // 当输入只有一个行的时候高度就是20多一点
        self.headImageView.frame = CGRectMake(10, 20, 40, 40);
        self.backView.frame = CGRectMake(60, 10, rec.size.width + 20, rec.size.height + 20);
        image = [UIImage imageNamed:@"SDBundle.bundle/收到气泡"];
        headImage = model.headerImage;
    }
    else // 模拟右边
    {
        self.headImageView.frame = CGRectMake(KmainWidth - 50, 20, 40, 40);
        self.backView.frame = CGRectMake(KmainWidth - 50 - rec.size.width - 20, 15, rec.size.width + 20, rec.size.height + 25);
        image = [UIImage imageNamed:@"SDBundle.bundle/发送气泡"];
        headImage = model.headerImage;
        
    }
    // 拉伸图片 参数1 代表从左侧到指定像素禁止拉伸，该像素之后拉伸，参数2 代表从上面到指定像素禁止拉伸，该像素以下就拉伸
    image = [image stretchableImageWithLeftCapWidth:image.size.width/10*9 topCapHeight:image.size.height/10*9];
    self.backView.image = image;
    self.headImageView.image = headImage;
    // 文本内容的frame
    self.contentLabel.frame = CGRectMake(model.isSend ? 5 : 13, 5, rec.size.width, rec.size.height);
    
    if ([model.message isEqualToString:@"voice"]) {
        
        self.contentLabel.text = @"🎵";
    }else{
    
        self.contentLabel.text = model.message;

    }
    
}


-(void)delegateAction{

    if (nil != self.delegate && [self.delegate respondsToSelector:@selector(tapWithbackView:)]) {
        
        
        [self.delegate tapWithbackView:self.cellModel];
        
    }
    

}


@end
