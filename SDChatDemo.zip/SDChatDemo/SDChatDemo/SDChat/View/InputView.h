//
//  InputView.h
//  SDChatDemo
//
//  Created by songjc on 16/12/1.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InputView : UIView

//InputView是输入框的view

/**
 输入框
 */
@property(nonatomic,strong)UITextView *inputTextView;


/**
 发送按钮
 */
@property(nonatomic,strong)UIButton *sendButton;


/**
 语音按钮
 */
@property(nonatomic,strong)UIButton *soundButton;


/**
 发送语音按钮
 */
@property(nonatomic,strong)UIButton *sendSoundButton;

@end
