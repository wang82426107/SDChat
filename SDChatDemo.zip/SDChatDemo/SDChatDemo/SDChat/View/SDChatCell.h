//
//  SDChatCell.h
//  SDChatDemo
//
//  Created by songjc on 16/12/1.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SDChatModel.h"

@protocol SDChatCellDelegate <NSObject>

-(void)tapWithbackView:(SDChatModel *)cellModel;

@end

@interface SDChatCell : UITableViewCell

//SDChatCell是聊天信息的Cell

@property (nonatomic,strong) UIImageView *headImageView; // 用户头像
@property (nonatomic,strong) UIImageView *backView; // 气泡
@property (nonatomic,strong) UILabel *contentLabel; // 气泡内文本
@property(nonatomic,assign)id <SDChatCellDelegate>delegate;

- (void)refreshCell:(SDChatModel *)model; // 安装我们的cell

@property(nonatomic,strong)SDChatModel *cellModel;

@end
