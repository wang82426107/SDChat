//
//  UserInformationView.h
//  SDChatDemo
//
//  Created by songjc on 16/12/6.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "XMPPvCardTemp.h"



@protocol UserInformationViewDelegate <NSObject>

@optional

//当点击头像触发的方法
-(void)clickHeaderView;

//当点击推出登录的时候触发的方法
-(void)logoutUser;

@end





@interface UserInformationView : UIView


//UserInformationView是个人信息页面的展示


/**
 头像图片模块
 */
@property(nonatomic,strong)UIImageView *headerImageView;

//代理
@property(nonatomic,assign)id<UserInformationViewDelegate> delegate;

/**
 签名档
 */
@property(nonatomic,strong)UILabel *signatureLabel;

//重新加载所有数据
-(void)reloadAllData;

@end
