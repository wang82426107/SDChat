//
//  UserInformationView.m
//  SDChatDemo
//
//  Created by songjc on 16/12/6.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "UserInformationView.h"
#import "SDXmppManager.h"
#import "SDUser.h"

@interface UserInformationView ()<UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate>

@property(nonatomic,strong)UITableView *informationList;

@property(nonatomic,strong)NSMutableArray *dataArray;

@end

@implementation UserInformationView

-(instancetype)initWithFrame:(CGRect)frame{

    if (self = [super initWithFrame:frame]) {
        
        self.backgroundColor = [UIColor whiteColor];
        
        [self loadInformationList];
        [self loadHeaderImageView];
    }

    return self;
}

#pragma mark ----头像模块----
-(void)loadHeaderImageView{

    UIView *headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height/4)];
    
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:headerView.frame];
    
    imageView.image = [UIImage imageNamed:@"头像背景.jpg"];
    
    [headerView addSubview:imageView];
    
    UIView *shareView = [[UIView alloc]initWithFrame:headerView.frame];
    
    shareView.backgroundColor = [UIColor colorWithRed:125/255.0 green:125/255.0 blue:125/255.0 alpha:0.3];
    
    [headerView addSubview:shareView];
    
    [self addSubview:headerView];
    
    //头像初始化
    self.headerImageView = [[UIImageView alloc]initWithFrame:CGRectMake(self.frame.size.width/2-headerView.frame.size.height*0.3, headerView.frame.size.height*0.1, headerView.frame.size.height*0.6, headerView.frame.size.height*0.6)];
    
    self.headerImageView.layer.cornerRadius  = headerView.frame.size.height*0.3;
    
    self.headerImageView.layer.masksToBounds = YES;
    
    self.headerImageView.layer.borderColor = (__bridge CGColorRef _Nullable)([UIColor orangeColor]);
    
    self.headerImageView.layer.borderWidth = 1.0f;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(showChangeHeaderImageAlertView)];
    [self.headerImageView addGestureRecognizer:tap];
    self.headerImageView.userInteractionEnabled = YES;
    
    [headerView addSubview:self.headerImageView];
    
    
    //签名档初始化
    self.signatureLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,  headerView.frame.size.height*0.75,  headerView.frame.size.width,  headerView.frame.size.height*0.25)];
    
    self.signatureLabel.textAlignment = NSTextAlignmentCenter;
    
    self.signatureLabel.textColor = [UIColor orangeColor];
    
    self.signatureLabel.font = [UIFont systemFontOfSize:15];
    
    self.signatureLabel.text = @"坚持不懈,莫忘初心";
    
    [headerView addSubview:self.signatureLabel];

    
    
}

-(void)showChangeHeaderImageAlertView{
    
    if (nil != self.delegate && [self.delegate respondsToSelector:@selector(clickHeaderView)]) {
        
        [self.delegate clickHeaderView];
    }


}


#pragma mark ----信息列表---
-(void)loadInformationList{

    self.informationList = [[UITableView alloc]initWithFrame:CGRectMake(40, self.frame.size.height/4*1, self.frame.size.width-40, self.frame.size.height/4*3) style:UITableViewStylePlain];
    
    self.informationList.delegate = self;
    self.informationList.dataSource = self;
    self.informationList.separatorStyle = NO;
    [self.informationList registerClass:[UITableViewCell class] forCellReuseIdentifier:@"informationList"];
    
    [self addSubview:self.informationList];
    
    XMPPvCardTemp *myCard = [SDXmppManager defaulManager].vCardTempModule.myvCardTemp;
    
    NSString *userName = [NSString stringWithFormat:@"  昵称: %@",myCard.nickname];
    
    self.dataArray = [NSMutableArray arrayWithArray:@[userName,@"  退出登录"]];
    
}

-(void)reloadAllData{

    XMPPvCardTemp *myCard = [SDUser defaulUser].vCard;
    
    NSString *userName = [NSString stringWithFormat:@"  昵称: %@",myCard.nickname];
    
    self.dataArray = [NSMutableArray arrayWithArray:@[userName,@"  退出登录"]];
    
    [self.informationList reloadData];

}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return self.dataArray.count;

}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"informationList"];
    
    cell.textLabel.text = self.dataArray[indexPath.row];
    
    cell.textLabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:18];
    
    cell.textLabel.textColor = SDcolor(50, 50, 50);
    
    if (indexPath.row == 0) {
        
        cell.imageView.image = [UIImage imageNamed:@"SDBundle.bundle/昵称.png"];

    }else{
    
        cell.imageView.image = [UIImage imageNamed:@"SDBundle.bundle/离开.png"];

    }
    
    cell.selectionStyle = UITableViewCellSeparatorStyleNone;
    return cell;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return 60;

}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    
    switch (indexPath.row) {
        case 0:{
            
            //修改用户名称
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"修改昵称" message:@"" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定",nil];
            
            [alert setAlertViewStyle:UIAlertViewStylePlainTextInput];
            [alert show];
        
        }
            break;
        case 1:{
            
            
            //退出登录.
            [[SDXmppManager defaulManager] disconnectWithServer];
            
            if (nil != self.delegate && [self.delegate respondsToSelector:@selector(logoutUser)]) {
                
                [self.delegate logoutUser];
            }
            
        }
            break;
            
        default:
            break;
    }

}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    if (buttonIndex == 1) {
        UITextField *textField = [alertView textFieldAtIndex:0];

        NSString *userName = [NSString stringWithFormat:@"  昵称: %@",textField.text];
        self.dataArray = [NSMutableArray arrayWithArray:@[userName,@"  退出登录"]];
        
        //上传服务器数据
        XMPPvCardTemp *myCard = [SDXmppManager defaulManager].vCardTempModule.myvCardTemp;
        myCard.nickname = textField.text;
        [[SDXmppManager defaulManager].vCardTempModule updateMyvCardTemp:myCard];
        [self.informationList reloadData];
        
    }
    
}


@end
