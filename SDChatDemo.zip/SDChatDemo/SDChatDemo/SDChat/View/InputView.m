//
//  InputView.m
//  SDChatDemo
//
//  Created by songjc on 16/12/1.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "InputView.h"

@implementation InputView

-(instancetype)initWithFrame:(CGRect)frame{

    if (self = [super initWithFrame:frame]) {
        
        self.backgroundColor = SDcolor(240, 240, 240);
        
        CGFloat viewWidth = frame.size.width;

        CGFloat viewHeight = frame.size.height;
        
        
        
        self.soundButton = [UIButton buttonWithType:UIButtonTypeCustom];
        self.soundButton.frame = CGRectMake(viewWidth*0.015, (viewHeight-viewWidth*0.12)/2, viewWidth*0.12, viewWidth*0.12);
        [self.soundButton setImage:[UIImage imageNamed:@"SDBundle.bundle/语音.png"] forState:UIControlStateNormal];
        [self.soundButton setImage:[UIImage imageNamed:@"SDBundle.bundle/键盘.png"] forState:UIControlStateSelected];
        [self.soundButton addTarget:self action:@selector(cutSoundAndWord) forControlEvents:UIControlEventTouchUpInside];
        [self.soundButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self addSubview:self.soundButton];

        
        self.sendSoundButton =[UIButton buttonWithType:UIButtonTypeCustom];;
        self.sendSoundButton.frame =CGRectMake(viewWidth*0.15, 8, viewWidth*0.67, viewHeight-16);
        [self.sendSoundButton setTitle:@"发送语音" forState:UIControlStateNormal];
        [self.sendSoundButton setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        self.sendSoundButton.layer.masksToBounds = YES;
        self.sendSoundButton.layer.cornerRadius = 5;
        self.sendSoundButton.layer.borderWidth = 2.0f;
        self.sendSoundButton.layer.borderColor = (__bridge CGColorRef _Nullable)(SDcolor(80, 80, 80));
        self.sendSoundButton.backgroundColor = SDcolor(255, 255, 255);
        [self addSubview:self.sendSoundButton];
    
        
        
        self.inputTextView = [[UITextView alloc]initWithFrame:CGRectMake(viewWidth*0.15, 8, viewWidth*0.67, viewHeight-16)];
        self.inputTextView.layer.masksToBounds = YES;
        self.inputTextView.font = [UIFont systemFontOfSize:15];
        self.inputTextView.layer.cornerRadius = 5;
        self.inputTextView.layer.borderWidth = 0.5f;
        self.inputTextView.layer.borderColor = (__bridge CGColorRef _Nullable)(SDcolor(180, 180, 180));
        self.inputTextView.backgroundColor = SDcolor(255, 255, 255);
        [self addSubview:self.inputTextView];
        
        
        
        self.sendButton = [UIButton buttonWithType:UIButtonTypeCustom];
        self.sendButton.frame = CGRectMake(viewWidth*0.85, viewHeight*0.2, viewWidth *0.12, viewHeight*0.6);
        [self.sendButton setTitle:@"发送" forState:UIControlStateNormal];
        [self.sendButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        self.sendButton.backgroundColor = SDcolor(126, 126, 126);
        self.sendButton.layer.cornerRadius = 3;
        self.sendButton.layer.masksToBounds = YES;
        //初始化就关闭用户交互,当输入框有内容的时候才会打开用户交互.
        self.sendButton.userInteractionEnabled  = NO;
        [self addSubview:self.sendButton];
        
        


    }
    
    return self;
}

-(void)cutSoundAndWord{
    
    self.soundButton.selected = !self.soundButton.selected;
    
    if (self.soundButton.isSelected) {
        
        [self insertSubview:self.inputTextView belowSubview:self.sendSoundButton];
        
        [self.inputTextView resignFirstResponder];
        
        
    }else{
    
        [self insertSubview:self.sendSoundButton belowSubview:self.inputTextView];
        
        
    
    }
    

}



@end
