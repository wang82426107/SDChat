//
//  FunctionCell.h
//  SDChatDemo
//
//  Created by songjc on 16/12/12.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FunctionCell : UITableViewCell

//FunctionCell是联系人功能菜单的Cell


/**
 头像
 */
@property (strong, nonatomic) IBOutlet UIImageView *iconsImageView;


/**
 功能名称Label
 */
@property (strong, nonatomic) IBOutlet UILabel *functionNameLabel;


/**
 消息数量Label
 */
@property (strong, nonatomic) IBOutlet UILabel *messageNumberLabel;


@end
