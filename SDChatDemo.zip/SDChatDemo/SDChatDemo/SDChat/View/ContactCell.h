//
//  ContactCell.h
//  SDChatDemo
//
//  Created by songjc on 16/11/30.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContactCell : UITableViewCell

//ContactCell是好友列表的cell,当前的cell只有两个显示属性,分别是姓名属性和头像属性.


/**
 头像的ImageView
 */
@property (strong, nonatomic) IBOutlet UIImageView *iconsImageView;


/**
 联系人名称Label
 */
@property (strong, nonatomic) IBOutlet UILabel *contactNameLabel;


/**
 上下线状态Lable
 */
@property (strong, nonatomic) IBOutlet UILabel *stateLabel;


/**
 上下线状态图标
 */
@property (strong, nonatomic) IBOutlet UIImageView *stateImage;


@end
