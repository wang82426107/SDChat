//
//  SDChatModel.m
//  SDChatDemo
//
//  Created by songjc on 16/12/1.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "SDChatModel.h"

@implementation SDChatModel

@end
