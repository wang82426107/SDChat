//
//  SDContactModel.h
//  SDChatDemo
//
//  Created by songjc on 16/12/8.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import <Foundation/Foundation.h>
@class XMPPJID;
@class XMPPvCardTemp;

@interface SDContactModel : NSObject

//SDContactModel是一个关于联系人的Model,包含着联系人的JID以及联系人的电子名片

@property(nonatomic,strong)XMPPJID *jid;

@property(nonatomic,strong)XMPPvCardTemp *vCard;

@property(nonatomic,assign)BOOL isAvailable;//是否在在线

@end
