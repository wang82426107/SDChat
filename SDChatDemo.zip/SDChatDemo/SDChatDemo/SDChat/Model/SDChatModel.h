//
//  SDChatModel.h
//  SDChatDemo
//
//  Created by songjc on 16/12/1.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XMPPMessageArchiving_Message_CoreDataObject.h"
@interface SDChatModel : NSObject

//SDChatModel是每一条消息的model,包含着消息内容,消息时间,以及消息是否是使用者本人发送的消息

@property(nonatomic,strong)NSString *message;

@property(nonatomic,strong)NSString *messageTime;

@property(nonatomic,strong)UIImage *headerImage;

@property(nonatomic,assign)BOOL isSend;

@property(nonatomic,strong)XMPPMessageArchiving_Message_CoreDataObject *msg;//消息的所有内容

@end
