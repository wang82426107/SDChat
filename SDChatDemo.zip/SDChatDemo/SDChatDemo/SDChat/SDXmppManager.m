//
//  SDXmppManager.m
//  SDChatDemo
//
//  Created by songjc on 16/12/4.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "SDXmppManager.h"
#import "XMPPvCardTemp.h"
//代表与服务器进行连接的类型.
typedef enum : NSUInteger {
    DoLgin,
    DoRegiser,
} ConnetType;

@interface SDXmppManager()<XMPPStreamDelegate,XMPPMessageArchivingStorage,XMPPRosterDelegate,XMPPvCardAvatarStorage,XMPPvCardTempModuleDelegate>

@property(nonatomic,strong)NSString *password;

@property(nonatomic,strong)NSString *regiserPassword;

//声明一个属性 记录连接的类型
@property(nonatomic,assign)ConnetType type;

@end

@implementation SDXmppManager

static SDXmppManager *manager;


+(instancetype)defaulManager{

    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        manager = [[SDXmppManager alloc]init];
        
    });

    return manager;

}

-(instancetype)init{

    if (self = [super init]) {
        
        self.stream = [[XMPPStream alloc]init];
        self.stream.hostName = kHostName;
        self.stream.hostPort = kHostPort;
        //设置stream的代理
        [self.stream addDelegate:self delegateQueue:dispatch_get_main_queue()];
        
        //下面这一堆其实是对roster对象进行初始化.
        //系统写好的XMPP存储对象
        self.rosterCoreDataStorage= [XMPPRosterCoreDataStorage sharedInstance];
        
        self.roster = [[XMPPRoster alloc]initWithRosterStorage:self.rosterCoreDataStorage dispatchQueue:dispatch_get_global_queue(0, 0)];
        
        //激活roster
        [self.roster activate:self.stream];
        
        //给roster对象指定代理
        [self.roster addDelegate:self delegateQueue:dispatch_get_main_queue()];
        
        //手动禁用自动获取名单
        self.roster.autoFetchRoster = NO;
        
        //自动连接
        self.reconnect = [[XMPPReconnect alloc] init];
        [self.reconnect activate:self.stream];
        
        //电子名片相关
        self.vCardCoreDataStorage = [XMPPvCardCoreDataStorage sharedInstance];
        self.vCardTempModule = [[XMPPvCardTempModule alloc]initWithvCardStorage:self.vCardCoreDataStorage];
        [self.vCardTempModule activate:self.stream];
        [self.vCardTempModule addDelegate:self delegateQueue:dispatch_get_main_queue()];
        self.vCardAvatarModule = [[XMPPvCardAvatarModule alloc]initWithvCardTempModule:self.vCardTempModule];
        [self.vCardAvatarModule activate:self.stream];
        [self.vCardAvatarModule addDelegate:self delegateQueue:dispatch_get_main_queue()];
        
        //初始化聊天记录管理对象
        
        XMPPMessageArchivingCoreDataStorage  *messageArchivingCoreDataStorage= [XMPPMessageArchivingCoreDataStorage sharedInstance];
        
        self.messageArchiving = [[XMPPMessageArchiving alloc]initWithMessageArchivingStorage:messageArchivingCoreDataStorage dispatchQueue:dispatch_get_main_queue()];
        
        //激活管理对象
        [self.messageArchiving activate:self.stream];
        
        //设置管理对象代理
        [self.messageArchiving addDelegate:self delegateQueue:dispatch_get_main_queue()];
        
        self.messageContext = messageArchivingCoreDataStorage.mainThreadManagedObjectContext;
        // 允许后台Socket运行.
        self.stream.enableBackgroundingOnSocket = YES;
        
        
    }
    
    return self;
}


#pragma mark ----注册、登录、退出---
-(void)loginWithUserName:(NSString *)name AndPassWord:(NSString *)password{
    
    self.password = password;
    self.type = DoLgin;
    [self connectToServerWintUser:name];
    
}



-(void)regiserWithUserName:(NSString *)name AndPassWord:(NSString *)password{
    
    self.regiserPassword = password;
    self.type = DoRegiser;
    [self connectToServerWintUser:name];

}



-(void)disconnectWithServer{
    
    [self.stream disconnect];

}


//与服务器的建立链接
-(void)connectToServerWintUser:(NSString *)name{
    
    if ([self.stream isConnected]) {
        
        [self.stream disconnect];
        
    }
    
    //jid jabberID,是基于jabber协议的由用户名生成的唯一ID
    self.stream.myJID = [XMPPJID jidWithUser:name domain:kDomin resource:kResource];
    
    NSLog(@"%@",self.stream.myJID);
    NSError *error = nil;
    
    //与服务器建立链接.
    [self.stream connectWithTimeout:30.0f error:&error];
    
    if (error != nil) {
        
        NSLog(@"连接失败!");
    }
    
}

#pragma mark ---XMPPStreamDelegate---

//与服务器建立连接
-(void)xmppStreamDidConnect:(XMPPStream *)sender{
    
    NSLog(@"与服务器建立链接正常");
    //与服务器进行登录认证
    NSError *error = nil;
    
    switch (self.type) {
        case DoLgin:
            [self.stream authenticateWithPassword:self.password error:&error];
            
            
            if (error != nil) {
                
                NSLog(@"认证过程出错!");
                
            }
            break;
            
        case DoRegiser:
            
            [self.stream registerWithPassword:self.regiserPassword error:&error];
            
            if (error != nil) {
                
                NSLog(@"注册过程出错!");
                
            }
            break;
    }
    
}

-(void)xmppStreamConnectDidTimeout:(XMPPStream *)sender{
    
    @throw [NSException exceptionWithName:@"CQ_Error" reason:@"与服务器建立连接超时" userInfo:nil];
    
}


@end
