//
//  SDRegisterHeaderVC.m
//  SDChatDemo
//
//  Created by songjc on 16/12/14.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "SDRegisterHeaderVC.h"
#import "XMPPvCardTemp.h"
#import "SDXmppManager.h"
#import "SDUser.h"
@interface SDRegisterHeaderVC ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property(nonatomic,strong)UIImageView *headerView;//头像视图

@property(nonatomic,strong)UIImage *headerImg;//头像

@property(nonatomic,strong)UIButton *registerButton;

@end

@implementation SDRegisterHeaderVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self loadNavigationView];
    
    [self loadHeaderView];
    
    [self.view addSubview:self.registerButton];
    
    self.view.backgroundColor = [UIColor colorWithPatternImage:[self reSizeImage:[UIImage imageNamed:@"墙纸图片.png"] toSize:CGSizeMake(KmainWidth, KmainHight)]];

}


-(void)loadNavigationView{
    
    self.navigationItem.title = @"选择头像";
    self.navigationController.navigationBar.barTintColor = SDcolor(52, 147, 255);
    [self.navigationController.navigationBar setTitleTextAttributes:
     
     @{NSFontAttributeName: [UIFont fontWithName:@"Helvetica-Bold" size:18],
       
       NSForegroundColorAttributeName:[UIColor whiteColor]}];
    
    self.navigationItem.hidesBackButton = YES;
    
    
}


-(UIButton *)registerButton{
    
    if (nil == _registerButton) {
        _registerButton = [[UIButton alloc]initWithFrame:CGRectMake(KmainWidth/4+20, 170+KmainWidth/2, KmainWidth/2-40, 45)];
        
        _registerButton.backgroundColor = SDcolor(232, 175, 96);
        
        [_registerButton setTitle:@"完成注册" forState:UIControlStateNormal];
        
        [_registerButton setTintColor:[UIColor whiteColor]];
        
        _registerButton.layer.cornerRadius = 4;
        
        _registerButton.layer.masksToBounds = YES;
        
        [_registerButton addTarget:self action:@selector(popLoginVC) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _registerButton;
}

-(void)popLoginVC{
    
    [SDUser defaulUser].isLogin = YES;


    XMPPvCardTemp *vCard = [SDXmppManager defaulManager].vCardTempModule.myvCardTemp;
    
    NSData *data;
    if (UIImagePNGRepresentation(self.headerImg) == nil)
    {
        UIImage *headerimage = [self reSizeImage:self.headerImg toSize:CGSizeMake(100, 100)];
        
        data = UIImageJPEGRepresentation(headerimage, 1.0);
        vCard.photo = data;
        
    }
    else
    {
        UIImage *headerimage = [self reSizeImage:self.headerImg toSize:CGSizeMake(100, 100)];
        data = UIImagePNGRepresentation(headerimage);
        vCard.photo = data;
        
    }
    
    [[SDXmppManager defaulManager].vCardTempModule updateMyvCardTemp:vCard];

    [self dismissViewControllerAnimated:YES completion:nil];

    [[SDXmppManager defaulManager] disconnectWithServer];
}


-(void)loadHeaderView{
    
    self.headerImg = [UIImage imageNamed:@"栋哥头像.jpg"];
    
    self.headerView = [[UIImageView alloc]initWithFrame:CGRectMake(KmainWidth/4, 150, KmainWidth/2, KmainWidth/2)];
    self.headerView.image = [self addImage:[UIImage imageNamed:@"栋哥头像.jpg"] toImage:[UIImage imageNamed:@"相框.png"]];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(clickHeaderView)];
    [self.headerView addGestureRecognizer:tap];
    self.headerView.userInteractionEnabled = YES;
    
    [self.view addSubview:self.headerView];
    
}

-(void)clickHeaderView{
    
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    
    __weak typeof(self)temp = self;
    UIAlertAction *alertAction1 = [UIAlertAction actionWithTitle:@"从相册选择" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        [temp showPhotoLibraryVC];
        
    }];
    
    [alertVC addAction: alertAction1];
    
    
    UIAlertAction *alertAction2 = [UIAlertAction actionWithTitle:@"拍照" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        
        [temp showCameraPickerVC];
    }];
    
    [alertVC addAction: alertAction2];
    
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    
    [alertVC addAction: cancelAction];
    
    [self presentViewController:alertVC animated:YES completion:nil];
    
}



#pragma mark ---调取相机---
-(void)showCameraPickerVC{
    
    
    //设置调用类型为相机
    UIImagePickerControllerSourceType  sourceType = UIImagePickerControllerSourceTypeCamera;
    
    if (![UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera]) {
        
        NSLog(@"本设备未发现摄像头!");
        
        return;
        
    }
    
    UIImagePickerController *pickerController = [[UIImagePickerController alloc]init];
    
    pickerController.sourceType = sourceType;
    
    pickerController.delegate = self;
    
    pickerController.allowsEditing = YES;//设置是否可以进行编辑
    
    [[UIApplication sharedApplication]setStatusBarHidden:YES];
    [self showDetailViewController:pickerController sender:nil];
    
}


-(void)showPhotoLibraryVC{
    
    UIImagePickerControllerSourceType  sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    UIImagePickerController *pickerController = [[UIImagePickerController alloc]init];
    
    pickerController.sourceType = sourceType;
    
    pickerController.delegate = self;
    
    pickerController.allowsEditing = YES;
    
    [self showDetailViewController:pickerController sender:nil];
    
}


-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    
    NSString *type = [info objectForKey:UIImagePickerControllerMediaType];
    
    //当选择的类型是图片
    if ([type isEqualToString:@"public.image"])
    {
        UIImage* image = [info objectForKey:@"UIImagePickerControllerEditedImage"];
        
        self.headerImg  = image;
        
        self.headerView.image = [self addImage:image toImage:[UIImage imageNamed:@"相框.png"]];
        
        [picker dismissViewControllerAnimated:YES completion:nil];
    }
    
}


//修改图片尺寸
- (UIImage *)reSizeImage:(UIImage *)image toSize:(CGSize)reSize{
    
    UIGraphicsBeginImageContext(CGSizeMake(reSize.width, reSize.height));
    
    [image drawInRect:CGRectMake(0, 0, reSize.width, reSize.height)];
    
    UIImage *reSizeImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return reSizeImage;
    
}



- (UIImage *)addImage:(UIImage *)image1 toImage:(UIImage *)image2 {
    UIGraphicsBeginImageContext(image2.size);
    
    // Draw image1
    [image1 drawInRect:CGRectMake(image2.size.width*0.01, image2.size.height*0.01, image2.size.width*0.97, image2.size.height*0.97)];
    
    // Draw image2
    [image2 drawInRect:CGRectMake(0, 0, image2.size.width, image2.size.height)];
    
    UIImage *resultingImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return resultingImage;
}

@end
