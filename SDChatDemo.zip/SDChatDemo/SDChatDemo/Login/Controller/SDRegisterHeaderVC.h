//
//  SDRegisterHeaderVC.h
//  SDChatDemo
//
//  Created by songjc on 16/12/14.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SDRegisterHeaderVC : UIViewController

//SDRegisterHeaderVC是用户注册账号成功之后选择头像的页面

@end
